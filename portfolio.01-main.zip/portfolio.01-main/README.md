# portfolio.01
I am a student at ajay kumar garg engineering college in APJ abdul kalam technical university .
I am pursuing mmy  btech degree with cumputer science and information tenchonoly branch.
My hobbies inculde drawing, sketching anf ofcourse coding too.
I am a begineer in this feild and i have no such experince with project works but in future for sure I will work on big projects .
I belong to mordabad ( uttar pradesh) city famous for brass items export in entire india and as well as to the whole world . And i am completing my graduation in  the city gaziabad( uttar pradesh) .
